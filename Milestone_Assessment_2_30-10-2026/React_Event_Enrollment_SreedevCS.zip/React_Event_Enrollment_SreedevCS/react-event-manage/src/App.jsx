import {Routes,Route,Navigate} from 'react-router-dom';
import {useState,useEffect} from 'react';
import Navbar from './components/Navbar';
import Events from './pages/Events';
import Registrations from './pages/Registrations';

function App() {
  const [registrations, setRegistrations] = useState(()=>{
    try{
      const savedRegistrations=localStorage.getItem('registrations');
      if(savedRegistrations)
      {
        const parsedData=JSON.parse(savedRegistrations)
        if(Array.isArray(parsedData))
        {
          return parsedData;
        }
      }
      return [];
    }
    catch(error)
    {
      console.error("Error while loading registrations: ",error);
      return [];
    }
  });

  useEffect(()=>{
    localStorage.setItem('registrations',JSON.stringify(registrations));
  },[registrations]);

  
  function handleCancel(id)
  {
    const confirmCancel=window.confirm('Do you really want to cancel this registration?');
    if(confirmCancel)
    {
      setRegistrations((prevRegistrations)=>prevRegistrations.filter((registration)=>registration.id!==id))
    }
  }
  return (
    <div className="app-shell">
      <Navbar />
      <Routes>
        <Route path="/" element={<Navigate to="/events" />} />
        <Route path="/events" element={<Events 
          registrations={registrations}
          setRegistrations={setRegistrations}
        />} />
        <Route path="/registrations" element={<Registrations 
          registrations={registrations}
          onCancel={handleCancel}
        />} />
      </Routes>
    </div>
  );
}

export default App;
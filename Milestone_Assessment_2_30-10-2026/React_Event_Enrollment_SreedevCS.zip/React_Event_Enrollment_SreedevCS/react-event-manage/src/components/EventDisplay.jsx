function EventDisplay({ event, onRegister, availableSeats }) {
    return (
        <article className="event-card">
            <h2>{event.title}</h2>
            <p>Event ID: {event.id}</p>
            <p>Category: {event.category}</p>
            <p>Date: {event.date}</p>
            <p>Time: {event.time}</p>
            <p>Total seats: {event.seats}</p>
            <p>Available seats: {availableSeats}</p>
            <button onClick={() => onRegister(event)} disabled={availableSeats === 0}>
                {availableSeats === 0 ? 'Fully Booked' : 'Register'}
            </button>

        </article>
    );
}

export default EventDisplay;
import {Link} from 'react-router-dom';

function Navbar() {
    return (
        <nav className="site-nav">
            <h1>Event Enrollment Manager</h1>
            <div className="site-nav-links">
                <Link to="/events">Events</Link>
                {' | '}
                <Link to="/registrations">Registrations</Link>
            </div>
        </nav>
    );
}

export default Navbar;
import { useEffect, useRef, useState } from 'react';
import events from '../data/events';
import EventDisplay from '../components/EventDisplay';

function Events({registrations,setRegistrations}) {
    const [search,setSearch]=useState('');
    const [category,setCategory]=useState('All');
    const [selectedEvent,setSelectedEvent]=useState(null);
    const [name,setName]=useState('');
    const [email,setEmail]=useState('');
    const [message,setMessage]=useState('');
    const [errors, setErrors] = useState({});
    const registrationFormRef=useRef(null);
    useEffect(()=>{
        if(selectedEvent)
        {
            registrationFormRef.current?.scrollIntoView({
                behavior:'smooth',
                block:'center',
            });
        }
    },[selectedEvent]);
    const filteredEvents=events.filter((event)=>{
        const matchesSearch=event.title.toLowerCase().includes(search.toLowerCase());
        const matchesCategory=category==='All' || event.category===category;
        return matchesSearch && matchesCategory;
    });

    function handleRegister(event){
        setSelectedEvent(event);
        setName('');
        setEmail('');
        setMessage('');
        setErrors({});
    }

    function handleSubmit(e)
    {
        e.preventDefault();
        const trimmedName=name.trim();
        const trimmedEmail=email.trim().toLowerCase();
        const nextErrors={};
        if(!trimmedName)
        {
            nextErrors.name='Please enter your name.';
        }
        const emailPattern=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if(!emailPattern.test(trimmedEmail))
        {
            nextErrors.email='Please enter a valid email address.';
        }
        if(Object.keys(nextErrors).length>0)
        {
            setErrors(nextErrors);
            return;
        }

        const alreadyRegistered = registrations.some(
            (registration) =>
                registration.eventId === selectedEvent.id &&
                registration.email === trimmedEmail
        );
        if(alreadyRegistered)
        {
            setErrors({email:'You have already registered for this event.'});
            return;
        }

        const activeRegistrations=registrations.filter((registration)=>registration.eventId===selectedEvent.id);
        if(activeRegistrations.length>=selectedEvent.seats)
        {
            setErrors({form:'Sorry, this event is fully booked.'});
            return;
        }

        const newRegistration={
            id:Date.now(),
            eventId:selectedEvent.id,
            name:trimmedName,
            email:trimmedEmail
        };
        setRegistrations((prevRegistrations)=>[...prevRegistrations,newRegistration]);
        setErrors({});
        setMessage('Registration successful!');
        setName('');
        setEmail('');
        setSelectedEvent(null);
    }

    function getAvailableSeats(event)
    {
        const activeRegistrations=registrations.filter((registration)=>registration.eventId===event.id);
        return event.seats-activeRegistrations.length;  
    }

    return (
        <main className="page-content">
            <h1 className="page-heading">Upcoming Events</h1>

            <div className="filters">
                <input
                    type="text"
                    placeholder="Search events..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />

                <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                >
                    <option value="All">All Categories</option>
                    <option value="Technology">Technology</option>
                    <option value="Arts">Arts</option>
                    <option value="Life Skills">Life Skills</option>
                </select>
            </div>

            <div className="event-grid">
                {filteredEvents.length > 0 ? (

                    filteredEvents.map((event) => (
                        <EventDisplay
                            key={event.id}
                            event={event}
                            onRegister={handleRegister}
                            availableSeats={getAvailableSeats(event)}
                        />
                    ))

                ) : (

                    <p className="empty-state">No events found.</p>

                )}
            </div>
            {selectedEvent && (

                <section ref={registrationFormRef} className="registration-form">

                    <h2>Register for {selectedEvent.title}</h2>

                    <form onSubmit={handleSubmit} noValidate>
                        <div>
                            <label htmlFor="registration-name">Full Name</label>
                            <input
                                id="registration-name"
                                type="text"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                placeholder="Enter your full name"
                                aria-invalid={Boolean(errors.name)}
                                aria-describedby={errors.name ? 'name-error' : undefined}
                            />
                            {errors.name && (
                                <p id="name-error" className="field-error" role="alert">
                                    {errors.name}
                                </p>
                            )}
                        </div>

                        <div>
                            <label htmlFor="registration-email">Email Address</label>
                            <input
                                id="registration-email"
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                placeholder="Enter your email"
                                aria-invalid={Boolean(errors.email)}
                                aria-describedby={errors.email ? 'email-error' : undefined}
                            />
                            {errors.email && (
                                <p id="email-error" className="field-error" role="alert">
                                    {errors.email}
                                </p>
                            )}
                        </div>

                        {errors.form && <p className="field-error" role="alert">{errors.form}</p>}


                        <div className="form-actions">
                            <button type="submit">
                                Submit Registration
                            </button>

                            <button
                                type="button"
                                onClick={() => setSelectedEvent(null)}
                            >
                                Cancel
                            </button>
                        </div>

                    </form>

                    {message && <p className="status-message">{message}</p>}

                </section>

            )}

            {message && !selectedEvent && <p className="status-message">{message}</p>}

        </main>
    );
}

export default Events;
import events from '../data/events';
function Registrations({registrations, onCancel}) {
    return (
        <main className="page-content">
            <h1 className="page-heading">My Registrations</h1>
            {registrations.length > 0 ? (
                <div className="registration-list">
                {registrations.map((registration)=>{
                    const event=events.find((event)=>event.id===registration.eventId);
                return(
                    <article className="registration-card" key={registration.id}>
                    <div>
                    <h2>{registration.name}</h2>
                    <p>Email: {registration.email}</p>
                    <p>Event: {event?event.title:'Unknown event'}</p>
                    <p>Event Date: {event?event.date:'N/A'}</p>
                    </div>
                    <button onClick={()=>onCancel(registration.id)}>Cancel Registration</button>
                    </article>
                );
                })}
                </div>
            ):(
                <p className="empty-state">No registrations found!</p>
            )}
        </main>
    );
}
export default Registrations;
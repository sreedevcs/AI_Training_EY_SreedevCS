## Installation

1. Clone or extract the project.

2. Navigate to the project directory:
    cd react-event-manage

3. Install dependencies:
    npm install

## Run the application

1. Start the server:
    npm run dev

2. Open the URL displayed in the terminal

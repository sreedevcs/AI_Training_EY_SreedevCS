import numpy as np
import pandas as pd

#1
print("-----------1----------------")
df=pd.read_csv("urban_mobility.csv")
print(df[:5])

#2
print("-----------2---------------")
df["Energy_Per_Km"]=df["Energy_Used_kWh"]/df["Distance_Km"]
print(df)

#3
print("-----------3---------------")
print(df[(df["Vehicle_Type"]=="Electric Van") & (df["Maintenance_Flag"]=="Yes")])

#4
print("-----------4---------------")
print(df.groupby("Vehicle_Type").agg({"Distance_Km":"mean","Trips_Count":"count"}))

#5
print("-----------5-------------------")

energy=df["Energy_Used_kWh"].to_numpy()
print("Mean : ",np.mean(energy))
print("Maximum : ",np.max(energy))
print("Minimum : ",np.min(energy))

#6
import matplotlib.pyplot as plt
avg_energy=df.groupby("Vehicle_Type")["Energy_Used_kWh"].mean()
avg_energy.plot(kind="bar")
plt.xlabel("Vehicle Type")
plt.ylabel("Energy Used (kWh)")
plt.show()

#7
print("---------------7------------------------")
import json
with open("equipment_events.json") as f:
    data=json.load(f)
# print(data)
for it in data:
    print(it["event_id"],it["asset"]["type"],it["asset"]["site"],it["severity"])

#8
print("-----------8-----------------------------")

for it in data:
    if it["temperature"]>70:
        print(it)
        print(it.get("actions","No actions recorded"))

#9
print("--------------------------9--------------------------------")

with open("coastal_monitoring_log.txt") as f:
    text=f.read()

print("Total words = ",len(text.split()))
print("Count of the word \'inspection\' = ",text.lower().count("inspection"))


#10
print("------------------------10----------------------------------")

for it in text.splitlines():
    if 'boardwalk' in it.lower() or 'maintenance' in it.lower() or 'wind' in it.lower():
        print(it)


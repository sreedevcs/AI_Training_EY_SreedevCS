CREATE database spare_parts_assessment

CREATE TABLE suppliers (
    supplier_id INT PRIMARY KEY,
    supplier_name VARCHAR(100),
    city VARCHAR(50)
);

CREATE TABLE parts (
    part_id INT PRIMARY KEY,
    part_name VARCHAR(100),
    category VARCHAR(50),
    unit_price DECIMAL(10,2),
    stock_qty INT
);

CREATE TABLE purchase_orders (
    po_id INT PRIMARY KEY,
    supplier_id INT REFERENCES suppliers(supplier_id),
    order_date DATE,
    status VARCHAR(30)
);

CREATE TABLE purchase_order_items (
    po_item_id INT PRIMARY KEY,
    po_id INT REFERENCES purchase_orders(po_id),
    part_id INT REFERENCES parts(part_id),
    quantity INT
);

INSERT INTO suppliers VALUES
(1,'Axis Components','Rajkot'),
(2,'Prime Industrial','Pune'),
(3,'Nova Engineering','Coimbatore'),
(4,'Delta Supply Works','Bhubaneswar'),
(5,'Mektron Systems','Nashik'),
(6,'Cobalt Traders','Surat');

INSERT INTO parts VALUES
(101,'Bearing Set','Mechanical',1250,38),
(102,'Control Relay','Electrical',850,60),
(103,'Hydraulic Seal','Mechanical',420,95),
(104,'Temperature Sensor','Electronics',1850,24),
(105,'Drive Belt','Mechanical',760,42),
(106,'PLC Module','Electronics',5400,10),
(107,'Fuse Pack','Electrical',290,120);

INSERT INTO purchase_orders VALUES
(1001,1,'2026-10-01','Received'),
(1002,2,'2026-10-02','Pending'),
(1003,3,'2026-10-03','Received'),
(1004,1,'2026-10-05','Pending'),
(1005,5,'2026-10-06','Cancelled');

INSERT INTO purchase_order_items VALUES
(1,1001,101,10),
(2,1001,103,20),
(3,1002,102,15),
(4,1002,104,6),
(5,1003,105,12),
(6,1003,107,30),
(7,1004,106,2),
(8,1005,103,10);


SELECT * from suppliers;
SELECT * from parts;
SELECT * from purchase_orders;
SELECT * from purchase_order_items;

-- 1
select * from parts where category='Mechanical';

--2
select * 
from parts
where unit_price>1000
order by unit_price desc;

--3
select category,avg(unit_price) as AvgPrice
from parts
group by category

--4
select category,sum(stock_qty) as TotalStockQty
from parts
group by category

--5
select s.supplier_name,p.order_date,p.status
from suppliers s join purchase_orders p ON s.supplier_id=p.supplier_id

--6
select po.po_id,p.part_name,poi.quantity,p.unit_price
from purchase_orders po 
join purchase_order_items poi 
ON po.po_id=poi.po_id 
join parts p 
ON p.part_id=poi.part_id 

--7
select po.po_id,p.part_name,poi.quantity,p.unit_price,poi.quantity*p.unit_price as line_total
from purchase_orders po 
join purchase_order_items poi 
ON po.po_id=poi.po_id 
join parts p 
ON p.part_id=poi.part_id 

--8
SELECT s.supplier_id,s.supplier_name,po.po_id,po.order_date,po.status
FROM suppliers s LEFT JOIN purchase_orders po ON s.supplier_id=po.supplier_id

--9
SELECT s.supplier_id,s.supplier_name,po.po_id,po.order_date,po.status
FROM suppliers s LEFT JOIN purchase_orders po ON s.supplier_id=po.supplier_id
WHERE po.po_id is NULL;

--10

CREATE VIEW purchase_order_summary AS
SELECT po.po_id,s.supplier_name,p.part_name,poi.quantity,p.unit_price,poi.quantity*p.unit_price as line_total,po.status
FROM purchase_orders po
JOIN suppliers s ON po.supplier_id=s.supplier_id
JOIN purchase_order_items poi ON poi.po_id=po.po_id
JOIN parts p ON poi.part_id=p.part_id;

SELECT * FROM purchase_order_summary WHERE status='Pending'

--11

CREATE OR REPLACE FUNCTION calculate_part_discount(amount DECIMAL(10,2))
RETURNS DECIMAL(10,2)
LANGUAGE plpgsql
AS $$
BEGIN
if amount>=2000 then RETURN amount*0.1;
else RETURN 0;
end if;
END;
$$;

select part_id,part_name,unit_price,calculate_part_discount(unit_price) as discount
from parts;

--12

CREATE OR REPLACE FUNCTION final_part_price(amount DECIMAL(10,2))
RETURNS DECIMAL(10,2)
LANGUAGE plpgsql
AS $$
BEGIN
RETURN amount-calculate_part_discount(amount);
END;
$$;

select part_id,part_name,unit_price,calculate_part_discount(unit_price) as discount,final_part_price(unit_price) as final_price
from parts;

--13

CREATE OR REPLACE PROCEDURE update_po_status(po_id INT,new_status VARCHAR)
LANGUAGE plpgsql
AS $$
BEGIN
	UPDATE purchase_orders
	SET status=new_status
	WHERE purchase_orders.po_id=update_po_status.po_id;
END;
$$;

----BEFORE CALL
SELECT * FROM purchase_orders WHERE po_id=1004;

CALL update_po_status(1004,'Cancelled')

----AFTER CALL
SELECT * FROM purchase_orders WHERE po_id=1004;

--14

CREATE OR REPLACE PROCEDURE mark_old_pending_orders()
LANGUAGE plpgsql
AS $$
BEGIN
	UPDATE purchase_orders
	SET status='Received'
	WHERE status='Pending' and order_date<'2026-10-04';
END;
$$;

----BEFORE CALL
SELECT * from purchase_orders where order_date<'2026-10-04';

CALL mark_old_pending_orders();

----AFTER CALL
SELECT * from purchase_orders where order_date<'2026-10-04'


--15
/*
If supplier_name,supplier_city,part_name,part_category,po_id and quantity were all stored repeatedly
in a large table, it leads to data redundancy. 

The repeated facts are:
1. The part_name and part_category are repeated for every order of that particular part.
2. The supplier_name and supplier_city are repeated for every purchase from the same supplier.

The solution is to divide the large table into four tables as:
1. Suppliers (supplier_id,supplier_name,city)
2. Parts (part_id,part_name,category)
3. Purchase_Orders (po_id,supplier_id)
4. Purchase_Order_Items (po_item_id,po_id,part_id,quantity)

The large table is normalized into 3NF by splitting unrelated attributes into separate tables 
based on their dependencies. Primary keys and foreign keys maintain the relationship among the 
tables.

*/